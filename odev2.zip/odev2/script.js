document.addEventListener('DOMContentLoaded', function() {
    const toastSuccess = document.getElementById('liveToast');
    const toastError = document.getElementById('liveToastError');
    const taskInput = document.getElementById('task');
    const taskList = document.getElementById('list');

    function showToast(toast) {
        $(toast).toast('show');
    }

    function newElement() {
        const taskText = taskInput.value.trim();

        if (taskText === "") {
            showToast(toastError);
        } else {
            const li = document.createElement('li');
            li.textContent = taskText;
            taskList.appendChild(li);
            taskInput.value = "";

            showToast(toastSuccess);
        }
    }

    taskList.addEventListener('click', function(e) {
        if (e.target.tagName === 'LI') {
            e.target.classList.toggle('checked');
        }
    });

    document.getElementById('liveToastBtn').addEventListener('click', newElement);
});